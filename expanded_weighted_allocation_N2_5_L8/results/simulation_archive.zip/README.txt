Requires Python with NumPy, SciPy, Matplotlib.
python expanded.py
python finish.py
python report.py
