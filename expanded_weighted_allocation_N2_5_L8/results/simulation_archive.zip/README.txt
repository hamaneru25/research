Requires Python with NumPy, SciPy, Matplotlib.
python report.py
For search reproduction including published single-photon warm starts, use the full GitHub repository.
